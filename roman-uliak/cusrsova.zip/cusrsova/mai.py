from app import CarRentalApp

if __name__ == "__main__":
    app = CarRentalApp()
    app.mainloop()
 